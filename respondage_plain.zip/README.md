# Respondage Plain
Plain LimeSurvey theme, plainer than LS Vanilla. For LS 3 only

Feel free to use. No obligations, no guarantees.
